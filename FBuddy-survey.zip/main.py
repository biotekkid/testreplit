from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit_survey', methods=['POST'])
def submit_survey():
    # Process and store survey data (you can use a database for this)
    question1 = request.form.get('question1')
    question2 = request.form.get('question2')

    # Redirect to the thank-you page
    return redirect(url_for('thank_you'))

@app.route('/thank_you')
def thank_you():
    return render_template('thank_you.html')

if __name__ == '__main__':
    app.run(debug=True)

